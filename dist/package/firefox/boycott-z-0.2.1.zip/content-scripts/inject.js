document.addEventListener("retrievePageVariable", () => {
    console.log('go here')
    document.dispatchEvent(
        new CustomEvent("variableRetrieved", {
            detail: runParams.data.productPropComponent.props,
        }),
    );
});
